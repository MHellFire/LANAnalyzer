LANAnalyzer

Version 0.1.0 (2009-10-26), 32-bit.

Based on Qt 4.5.3 & WinPcap 4.1.1.

Copyright � 2009 Mariusz Helfajer

http://helfajer.info



License

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.



Icons

Crystal Project Icons

Copyright (c) 2006-2007 Everaldo Coelho.
The Crystal Project are released under LGPL.

http://www.everaldo.com


Fugue Icons Version 2.2.2 (July 27, 2009)

Copyright (C) 2009 Yusuke Kamiyamane. All rights reserved.
The icons are licensed under a Creative Commons Attribution
3.0 license. <http://creativecommons.org/licenses/by/3.0/>

http://www.pinvoke.com


Diagona Icons

Copyright (C) 2007 Yusuke Kamiyamane. All rights reserved.
The icons are licensed under a Creative Commons Attribution
3.0 license. <http://creativecommons.org/licenses/by/3.0/>

http://pinvoke.com
